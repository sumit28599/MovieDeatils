//
//  Constant.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import Foundation

enum Constant {
    enum API {
        static let baseMovieURL = "https://simplifiedcoding.net/demos/marvel"
    }
}

let userStandard = UserDefaults.standard

enum UserDefaultKey: String {

    case isAlreadyLogin = "isAlreadyLogin"
    case userId = "userId"
    case userName = "userName"
    case registerUserCount = "registerUserCount"

}
