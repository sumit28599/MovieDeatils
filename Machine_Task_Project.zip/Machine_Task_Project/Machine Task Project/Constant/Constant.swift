//
//  Constant.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

enum Constant {
    enum API {
        static let baseMovieURL = "https://simplifiedcoding.net/demos/marvel"
    }
}
