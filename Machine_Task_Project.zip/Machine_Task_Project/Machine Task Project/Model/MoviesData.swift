//
//  MoviesData.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import Foundation

struct MoviesData: Codable {
    let name: String
    let realname: String
    let team: String
    let firstappearance: String
    let createdby: String
    let imageurl: String
    let publisher: String
    let bio: String
}


