//
//  EndPointType.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import Foundation

enum HTTPMethods: String {
    case get = "GET"
}

protocol EndPointType {
    var url: URL? { get }
    var method: HTTPMethods { get }
    var body: Encodable? { get }
    var headers: [String: String]? { get }
}
