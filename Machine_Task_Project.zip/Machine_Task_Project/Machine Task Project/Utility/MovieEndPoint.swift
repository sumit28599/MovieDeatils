//
//  MovieEndPoint.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import Foundation

enum MovieEndPoint {
    case products
}

extension MovieEndPoint: EndPointType {

   

    var url: URL? {
        return URL(string: Constant.API.baseMovieURL)
    }

    var method: HTTPMethods {
            return .get
    }

    var body: Encodable? {
            return nil
    }

    var headers: [String : String]? {
        APIManager.commonHeaders
    }
}
