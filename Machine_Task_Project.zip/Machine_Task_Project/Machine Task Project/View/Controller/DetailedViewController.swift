//
//  DetailedViewController.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import UIKit

class DetailedViewController: UIViewController {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var realNameLabel: UILabel!
    @IBOutlet weak var publisherLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var createdLabel: UILabel!
    @IBOutlet weak var bioLabel: UILabel!
    
    var name = ""
    var realname = ""
    var team = ""
    var firstappearance = ""
    var createdby = ""
    var imageurl = ""
    var publisher = ""
    var bio = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        mainView.makeViewCircular()
        APIData ()
    }
    

    func APIData () {
        nameLabel.text = "Name: \(name)"
        realNameLabel.text = "RealName: \(realname)"
        teamLabel.text = "Team: \(team)"
        yearLabel.text = "Year: \(firstappearance)"
        createdLabel.text = "Createdby: \(createdby)"
        bioLabel.text = "Description: \(bio)"
        publisherLabel.text = "Publisher: \(publisher)"
        productImageView.setImage(with: imageurl)
    }
    
    @IBAction func backBtnClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}


