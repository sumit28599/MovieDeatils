//
//  ViewController.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var userNametxt: UITextField!
    @IBOutlet weak var passwordtxt: UITextField!
    @IBOutlet weak var userView: UIView!
    @IBOutlet weak var passwordView: UIView!
    
    //MARK: Variables
    var isComingFromSignup = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userView.layer.borderColor = UIColor.black.cgColor
        userView.layer.borderWidth = 1
        
        passwordView.layer.borderColor = UIColor.black.cgColor
        passwordView.layer.borderWidth = 1
        
    }

    //MARK: Signup Tap Action
    @IBAction func signUpAction(_ sender: Any) {

        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as? SignUpViewController
      self.navigationController?.pushViewController(vc!, animated: true)

    }

    //MARK: Login Tap Action
    @IBAction func loginAction(_ sender: Any) {
        
        let userName = userNametxt.text ?? ""
        let password = passwordtxt.text ?? ""
        
        if checkValidation(userName: userName, password: password) {
            let loginUserResult = UserManager.shared.checkUserAbleToLogin(userName: userName, password: password)
            if loginUserResult.errorCode == 200 {
                userStandard.set(loginUserResult.userDetails?.userId, forKey: UserDefaultKey.userId.rawValue)
                userStandard.set(loginUserResult.userDetails?.userName, forKey: UserDefaultKey.userName.rawValue)
                
                userStandard.set("1", forKey: UserDefaultKey.isAlreadyLogin.rawValue)
            }
            else {
                showAlert(message: loginUserResult.errorMessage)
            }
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MovieListViewController") as? MovieListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    //MARK: Check validation
    private func checkValidation(userName: String, password: String) -> Bool {
        
        if userName == "" {
            showAlert(message: "Please enter email")
        }
       
        else if password == "" {
            showAlert(message: "Please enter password")
        }
        else {
            return true
        }
        return false
    }

    private func showAlert(message: String) {

        Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: false, message: message, yesActionTitle: "Okay") { _ in }
        
        let userValue = User()
    }
    
}

