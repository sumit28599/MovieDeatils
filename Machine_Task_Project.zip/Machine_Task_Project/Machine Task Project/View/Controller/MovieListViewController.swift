//
//  MovieListViewController.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import UIKit

class MovieListViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var movieTableView: UITableView!
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - Variables
    private var viewModel = MovieViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        configuration()
    }
    
    @IBAction func backBtnClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension MovieListViewController {
    
    func configuration() {
        movieTableView.register(UINib(nibName: "MovieCell", bundle: nil), forCellReuseIdentifier: "MovieCell")
        initViewModel()
        observeEvent()
    }
    
    func initViewModel() {
        viewModel.fetchProducts()
    }
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self else { return }
            
            switch event {
            case .loading:
                /// Indicator show
                print("Product loading....")
            case .stopLoading:
                // Indicator hide kardo
                print("Stop loading...")
            case .dataLoaded:
                print("Data loaded...")
                DispatchQueue.main.async {
                    // UI Main works well
                    self.movieTableView.reloadData()
                }
            case .error(let error):
                print(error)
                
            }
        }
    }
    
}

extension MovieListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCell") as? MovieCell else {
            return UITableViewCell()
        }
        let product = viewModel.products[indexPath.row]
        cell.product = product
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCell", for: indexPath) as! MovieCell
        let product = viewModel.products[indexPath.row]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DetailedViewController") as! DetailedViewController
        
        vc.name = product.name
        vc.realname = product.realname
        vc.team = product.team
        vc.firstappearance = product.firstappearance
        vc.createdby = product.createdby
        vc.publisher = product.publisher
        vc.imageurl = product.imageurl
        vc.bio = product.bio
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
