//
//  MovieCell.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import UIKit

class MovieCell: UITableViewCell {

    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var productBackgroundView: UIView!
    @IBOutlet weak var productTitleLabel: UILabel!
    @IBOutlet weak var productCategoryLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var createdLabel: UILabel!

    var product: MoviesData? {
        didSet {
            productDetailConfiguration()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        productBackgroundView.clipsToBounds = false
        productBackgroundView.layer.cornerRadius = 15

        productImageView.layer.cornerRadius = 10

        self.productBackgroundView.backgroundColor = .systemGray6
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func productDetailConfiguration() {
        guard let product else { return }
        productTitleLabel.text = "Name: \(product.name)"
        productCategoryLabel.text = "RealName: \(product.realname)"
     //   descriptionLabel.text = "\(product.bio)"
        teamLabel.text = "Team: \(product.team)"
        createdLabel.text = "CreatedBy: \(product.createdby)"
        yearLabel.text = product.firstappearance
        productImageView.setImage(with: product.imageurl)
    }
    
}
